


class CobaData:
    def __init__(hihi):
        hihi.text=' amsdkmasd'
    def getText(self):
        return self.text