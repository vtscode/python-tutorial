"""
Rute URL adalah sebuah struktur navigasi yang menghubungkan antara halaman satu dengan halaman lainnya dalam sebuah website. Berikut ini contoh gambaran rute URL yang akan kita buat.

/
/home
/about
/contact

"""
